#include <bits/stdc++.h>
#include <sys/select.h>
#include <sys/time.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <unistd.h>
using namespace std;
#define PORT 9999

int main() {
	struct sockaddr_in address;
	int sock = 0, valread;
	struct sockaddr_in serv_addr;
	string msg = "Hello from client";
	char buf[1024];
	sock = socket(AF_INET, SOCK_STREAM, 0);
	printf("Socket got = %d \n",sock );
	if (sock < 0) {
		perror("Socket failed");
		exit(1);
	}

	memset(&serv_addr, '0', sizeof(serv_addr));
	serv_addr.sin_family = AF_INET;
	serv_addr.sin_addr.s_addr = inet_addr("127.0.0.1");
	serv_addr.sin_port = htons(PORT);
	int cval = connect(sock, (struct sockaddr *) &serv_addr, sizeof(serv_addr));
	printf("cval : %d\n", cval);
	if (cval < 0) {
		perror("Connect failed");
		exit(1);
	}
	printf("Connection established with IP %s Port %d \n",inet_ntoa(serv_addr.sin_addr),ntohs(serv_addr.sin_port) );
	printf("Sending message : %s \n",msg.c_str());
	int val = send(sock, msg.c_str(), 1024, 0);
	printf("Message sent: %d\n", val);
	// valread = recv(sock, buf, 1024, 0);
	// printf("buf: %s\n", buf);
}