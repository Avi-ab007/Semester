#include <bits/stdc++.h>
using namespace std;

int main(){
	cout<<"This is the program P4.\n";
}