type "make" to compile all programs
execute in the order 'sudo ./firewall' './server <server number>' './client <client number' in seperate terminals